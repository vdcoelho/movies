import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../environments/environment';
import { Observable, of } from 'rxjs';
import { Movie } from '../models/movie';
import { Auth } from './auth';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  url = environment.apiUrl + '/api/v1/movies/';

  constructor(private http: HttpClient, private auth:Auth) { }

  findByTitle(title: string): Observable<Movie> {

    return this.http.get<Movie>(this.url + `by-title?title=${title}`, {headers: this.auth.getHeader()});
  }

}
