import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Nominee } from '../models/nominee';
import { environment } from './../../environments/environment';
import { Auth } from './auth';

@Injectable({
  providedIn: 'root'
})
export class NomineeService {

  url = environment.apiUrl + '/api/v1/nominees/';

  constructor(private http: HttpClient, private auth: Auth) { }

  findNomineeByTitle(title: string): Observable<Nominee> {
    return this.http.get<Nominee>(this.url + `by-movie?title=${title}`, {headers: this.auth.getHeader()})
  }
}
