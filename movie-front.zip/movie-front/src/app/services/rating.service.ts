import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Rating } from '../models/rating';
import { environment } from './../../environments/environment';
import { Auth } from './auth';

@Injectable({
  providedIn: 'root'
})
export class RatingService {
  
  url = environment.apiUrl + '/api/v1/ratings/';
  
  constructor(private http: HttpClient, private auth:Auth) { }

  top10Rated(): Observable<Rating[]> {
    return this.http.get<Rating[]>(this.url + `top10-rated`, {headers: this.auth.getHeader()})
  } 

  rate(title: string, rate: number): Observable<any> {
    let obj = {'title': title, 'rate':rate};
    console.log('posting: ', obj);
    return this.http.post<any>(`${this.url}`, obj, {headers: this.auth.getHeader()});
  }

}
