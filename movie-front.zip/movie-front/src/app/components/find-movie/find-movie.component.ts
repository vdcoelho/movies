import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/models/movie';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-find-movie',
  templateUrl: './find-movie.component.html',
  styleUrls: ['./find-movie.component.css']
})
export class FindMovieComponent implements OnInit {

  title: string = '';
  information: string = '';
  movie: Movie = <Movie> { } ;

  constructor(
    private movieService: MovieService
  ) { }

  ngOnInit(): void {
  }

  findByTitle(title: string) {
    console.log('finding title ', title);
    this.movie = <Movie> {};
    this.movieService.findByTitle(title).subscribe(
      {
        next: (m) => this.movie = m,
        error: (e) => this.information = e.error?.message,
        complete: () => this.information = ''
        
      }
    );
  }

}
