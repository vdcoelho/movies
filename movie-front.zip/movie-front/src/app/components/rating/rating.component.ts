import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';
import { RatingService } from 'src/app/services/rating.service';
import { RatingDecimalComponent } from '../gui/rating-decimal/rating-decimal.component';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {
  ctrl = new FormControl(null, Validators.required);
  @Input() movieTitle!: string;
  information: string = 'Please click to rate';

  constructor(private ratingService: RatingService) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.ctrl.setValue(null);
    this.information = 'Please click to rate';
    this.ctrl.enable();
  }

  rate(rating: number) {        
    if (!rating) return;

    this.ratingService.rate(this.movieTitle, rating).subscribe(
      {
        next: (r) => this.rated(),
        error: (e) => { this.information = e.error.message; this.ctrl.setValue(null)},
        complete: () => this.information = ''
      }
    );
  }   

  rated() {
    this.ctrl.disable();
  }
  

  toggle() {
    if (this.ctrl.disabled) {
      this.ctrl.enable();
    } else {
      this.ctrl.disable();
    }
  }

}
