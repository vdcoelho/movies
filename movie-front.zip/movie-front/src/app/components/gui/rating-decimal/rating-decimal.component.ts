import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-rating-decimal',
  templateUrl: './rating-decimal.component.html',
  styleUrls: ['./rating-decimal.component.css']
})
export class RatingDecimalComponent implements OnInit {

  @Input() currentRate: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

}
