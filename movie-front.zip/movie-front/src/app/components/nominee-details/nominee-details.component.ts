import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { Nominee } from 'src/app/models/nominee';
import { NomineeService } from 'src/app/services/nominee.service';

@Component({
  selector: 'app-nominee-details',
  templateUrl: './nominee-details.component.html',
  styleUrls: ['./nominee-details.component.css']
})
export class NomineeDetailsComponent implements OnInit {

  @Input() movieTitle!: string;
  nominee: Nominee = <Nominee> {} ;
  information: string = '';

  constructor(private nomineeService: NomineeService) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    this.findNomineeByMovieTitle(this.movieTitle);
  }

  findNomineeByMovieTitle(movieTitle: string) {
    if (!movieTitle) {
      return;
    }
    this.nomineeService.findNomineeByTitle(movieTitle).subscribe(
      {
        next: (m) => this.nominee = m,
        error: (e) => this.information = e.error?.message,
        complete: () => this.information = ''
        
      }
    );
  }

}
