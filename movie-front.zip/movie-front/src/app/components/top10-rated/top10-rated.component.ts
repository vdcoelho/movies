import { Component, OnInit } from '@angular/core';
import { Rating } from 'src/app/models/rating';
import { RatingService } from 'src/app/services/rating.service';

@Component({
  selector: 'app-top10-rated',
  templateUrl: './top10-rated.component.html',
  styleUrls: ['./top10-rated.component.css']
})
export class Top10RatedComponent implements OnInit {

  top10!: Rating[];
  information: string = '';

  constructor(private ratingService : RatingService) { }

  ngOnInit(): void {
    this.loadTop10();
  }

  loadTop10() {
    this.ratingService.top10Rated().subscribe(
      {
        next: (r) => this.top10 = r,
        error: (e) => this.information = e.error.message,
        complete: () => this.information = ''        
      }
    );
  }

}
