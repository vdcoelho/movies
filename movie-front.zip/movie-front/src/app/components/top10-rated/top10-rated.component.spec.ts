import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Top10RatedComponent } from './top10-rated.component';

describe('Top10RatedComponent', () => {
  let component: Top10RatedComponent;
  let fixture: ComponentFixture<Top10RatedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Top10RatedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Top10RatedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
