import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FindMovieComponent } from './components/find-movie/find-movie.component';
import { MovieDetailsComponent } from './components/movie-details/movie-details.component';
import { NomineeDetailsComponent } from './components/nominee-details/nominee-details.component';
import { Top10RatedComponent } from './components/top10-rated/top10-rated.component';
import { RatingComponent } from './components/rating/rating.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RatingDecimalComponent } from './components/gui/rating-decimal/rating-decimal.component';
import { CardComponent } from './components/gui/card/card.component';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    FindMovieComponent,
    MovieDetailsComponent,
    NomineeDetailsComponent,
    Top10RatedComponent,
    RatingComponent,
    RatingDecimalComponent,
    CardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
