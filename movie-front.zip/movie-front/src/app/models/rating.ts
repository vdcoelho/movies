export interface Rating {
    imdbID: string,
    title: string,
    votes: number,
    rating: number,
    boxOffice: number | null
}
