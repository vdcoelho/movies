export interface Nominee {
    category: string,
    wasWinner: boolean,
    wasNominee: boolean,
    yearOfNominated: string
}
