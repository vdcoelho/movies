export interface Movie {
    title: string,
    year: string,
    rated: string,
    released: string,
    runtime: string,
    genre: string,
    poster: string,
    boxOffice: string,
    imdbID: string
}
